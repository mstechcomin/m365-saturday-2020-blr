// Default entry point for client scripts
// Automatically generated
// Please avoid from modifying to much...

